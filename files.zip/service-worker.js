// ============================================================
//  IROHAD'ECOR — Service Worker
//  オフラインでも全機能が使えるようにキャッシュ管理
// ============================================================

const CACHE_NAME = 'irohad-v1';

// キャッシュするファイル一覧（全HTMLとアセット）
const CACHE_FILES = [
  './',
  './index.html',
  './irohad_daily_report.html',
  './irohad_dashboard.html',
  './irohad_ecor_hearing_sheet_v2.html',
  './irohad_setup_guide.html',
  './irohad_estimate.html',
  './irohad_shift.html',
  './irohad_design_manual.html',
  './irohad_rules.html',
  './irohad_planter.html',
  './zaizan_mihoncho.html',
  './irohad_checklist.html',
  './irohad_mvv.html',
  './irohad_notebook.html',
  './tsubomi_notebook.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
];

// インストール時：全ファイルをキャッシュ
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(CACHE_FILES.filter(f => !f.startsWith('https://fonts')));
    }).then(() => self.skipWaiting())
  );
});

// アクティベート時：古いキャッシュを削除
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// フェッチ時：キャッシュ優先（オフライン対応）
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        // 成功したレスポンスをキャッシュに追加
        if (response && response.status === 200 && response.type !== 'opaque') {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      }).catch(() => {
        // オフライン時のフォールバック
        if (event.request.destination === 'document') {
          return caches.match('./index.html');
        }
      });
    })
  );
});
